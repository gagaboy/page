Resource list for all mockup and pictures:

MOCKUPS
MackBook mockup     - https://dribbble.com/shots/1403640-MacBook-Pro
Browser mockup      - https://dribbble.com/shots/1460141-Free-minimal-browser-window
Iphone mockup       - https://dribbble.com/shots/1114707-FREE-PSDs-iGravertical-Screen-Layers-iOS-7-Screen-Converter?list=searches&offset=2
Ipad mockup         - http://www.pixeden.com/psd-mock-up-templates/perspective-tablet-mock-up

IMAGES
Avatars             - http://uifaces.com/
1 slider            - https://ununsplash.imgix.net/39/lIZrwvbeRuuzqOoWJUEn_Photoaday_CSD%20%281%20of%201%29-5.jpg?q=75&fm=jpg&s=51271112596da893693f98a61c47b619
2 slider            - https://dribbble.com/shots/1736601-6-Photorealistic-iPhone-6-mockups
